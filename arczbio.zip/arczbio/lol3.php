<?php
	$menu = array('kategoria_1.php' => 'kategoria 1', 'kategoria_2.php' => 'kategoria 2', 'kategoria_3.php' => 'Kategoria 3');
	foreach ($menu as $key => $value):
?>
<li><a href="<? php echo $key ?>"> <?php echo $value?> </a></li>
<?php endforeach ?>